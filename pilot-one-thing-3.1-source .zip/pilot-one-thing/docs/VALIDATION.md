# 交付验证记录

版本 **1.9**（versionCode 10）。本文件记录实际执行过的检查与结果；未执行的项目明确标注，不把构建成功等同于功能通过。

## 无色透明 + 强折射 + 光学层清空 bug 修复（v1.9）

用户反馈"效果不够强、我要透明无色怎么还整上颜色了"。本版把玻璃彻底无色化并加强真实折射，同时修复了一个导致光学层在真机整层全空的隐藏 bug。

- **无色（实测）：** 用户设备 87 场景，canvas 光学层中行逐像素 `max(R,G,B)-min(R,G,B)=0`（完全中性）；CSS 玻璃/滑块背景与阴影全为白色/中性灰，无任何 `saturate()`；`backdrop-filter` 计算值为纯 `url("#glass-refract")`。颜色仅来自被折射的背景。
- **折射增强（实测）：** `feDisplacementMap scale=50`（v1.8 为 30）；实验对比 30/44/58/72 后选定 50——条纹弯折明显且圆角不露白。真实 App 垫棋盘截图（`refraction-clear-1.9.png`）与真实内容截图（`refraction-content-clear-1.9.png`）可见背后条纹/文字在玻璃边缘明显弯折。
- **中心通透（实测）：** 光学层中心 alpha=7/255（背景折射不被蒙），边缘峰值 alpha=210，无过曝像素（blown=0）。
- **隐藏 bug 修复（实测）：** 修复前 canvas 逐帧被 `measure()`（DPR 尺寸 546）与软件路径（逻辑尺寸 312）互相清空，且循环内 `var c/g` 覆盖光源向量产生 NaN——导致 `putImageData` 写入的 alpha 全 0（仅首像素幸免）。修复后非零像素从 1 个增至 50186 个（整块玻璃），`maxChannelDiff=0`。
- **回归：** 三场景（87 用户设备 / 74 旧引擎 / 120 现代）全通过、高光随光照左右偏置翻转（L-R 22→-13）、点击/滑块吸附/胶囊拖拽交互正常、0 JS 错误；既有 20 项 UI 回归通过；Android Lint BUILD SUCCESSFUL（0 错误）。
- **验证缺口（如实标注）：** 本环境只有 Chromium 144，用用户精确 UA 87.0.4280.101 覆盖 + 同引擎能力探测复现，`backdrop-filter: url()` 属 Chromium 特性、87 在支持范围，但无法运行真正的 Chromium 87 WebView 引擎；真机 87 的 SVG-filter backdrop 渲染仍需用户覆盖安装后确认。

## 真正的背景折射（v1.8，关键根因修复）

> 用户反馈"还是没有折射"并要求上网查证厂商做法。确认业界真折射 = 对玻璃背后内容做位移扭曲（`feDisplacementMap` + `backdrop-filter: url()`），而非 canvas 反光。根因：v1.5 的探测把**所有 Android UA 判为 legacy**，真实折射分支从未在真机启用。

- **引擎**：Chromium 144 覆盖用户确切 UA `Chrome/87.0.4280.101`（Android 10）。87 > 76，属支持 `backdrop-filter: url()` 的 Chromium。
- **折射链路（场景 A，实测通过）**：`<html>` 类含 `glass-bdurl`、不含 `glass-legacy-webview`；计算出的 `backdrop-filter = url("#glass-refract") saturate(1.06)`；`feImage` 位移图内嵌有效；`feDisplacementMap scale=30`；`<html>` 到 dock 之间**无 backdrop-root 破坏**（opacity/filter/mix-blend/will-change 全为初始值）；WebGL 从未被请求，`#dock-optics` 走 2D。
- **视觉证据**：`/workspace/refraction-real-1.8.png`（真实导航 + 高对比棋盘底）——背后竖条纹在左右圆角与上下边缘明显弯折/挤压，中心相对平直；`/workspace/refraction-content-behind-1.8.png`（真实滚动内容）——文字经过导航时被折射错位。
- **降级（场景 B，Chromium 74）**：legacy tier，`saturate()` 保留、无 url()、canvas 玻璃仍绘制（中心 alpha≥10）、交互通过。
- **现代引擎（场景 C，Chrome 120）**：url() 折射仍启用。
- 三场景 0 JS 错误；`node --check` 通过；既有 20 项 UI 回归、Lint 0 错误。
- **未完成 / 限制**：本环境无法运行真正的 Chromium 87 WebView 引擎，验证为"Chromium 144 + 精确 UA 覆盖 + 同引擎能力探测"。Chromium 87 对 SVG-filter backdrop 的实际渲染需真机确认；若 87 引擎对此支持有差异，`saturate()` 降级与 canvas 高光仍保证玻璃可见。

## 整面透镜折射（v1.7，整块玻璃观感）

> 用户反馈"四边折射固定且难看、中间没有折射"。v1.7 把光学模型从边缘彩边改为整面凸透镜，软件路径与 WebGL shader 同步实现。

| 检查 | 结果 |
| --- | --- |
| 场景 A：安卓 10 WebView UA（Chrome/74）+ WebGL 可用 | `glass-software-optics` 标记，`getContext` 序列 `['2d']`，GL 从未使用 |
| A：中心反光 | 中心 alpha 88/255（有玻璃感，非全空；仍可透视内容） |
| A：整面覆盖 | 中间 60% 区域 100% 有玻璃光学覆盖（此前几乎为 0） |
| A：高光随光照移动 | 内部面亮度重心随指针 `0.464 → 0.519`（合成 pointermove 到两端） |
| A：过曝 | 0 个过曝像素 |
| A：色散 | 柔和光谱跨度 0..75（不再是固定双色描边） |
| A：交互 / JS 错误 | 点击、滑块吸附、胶囊拖拽通过；0 错误 |
| 既有 UI 回归 `tests/ui/verify-ui.cjs` | PASS，20 项响应式检查，0 错误 |
| `glass.js` 语法 | 通过 |

> 光学观感由离线实验 `tools/art/glass-lab.cjs` 迭代定型，再由 `/workspace/refraction-preview-1.7.png`（canvas 像素导出 + 棋盘底）直观确认。

## 安卓真机「玻璃发平」根因修复（v1.6，关键）

> v1.5 只加了 CSS/SVG 能力探测，但真机仍"一点变化也没有"。根因是此前所有光学验证都在无 WebGL 的 Chromium 里进行、测的全是软件路径；真机 WebView 的 WebGL 上下文能创建、shader 能编译，却合成出全透明画面，旧逻辑因 `program` 存在永不调用 `software()`，整层折射为空白。v1.6 让安卓引擎强制走软件 2D 路径并增强色散。

| 检查 | 结果 |
| --- | --- |
| 场景 A：安卓 10 WebView UA（Chrome/74）**且 WebGL 可用** | 根节点标记 `glass-software-optics` |
| A：`#dock-optics.getContext()` 调用序列 | `['2d']` —— **WebGL 从未被请求**，彻底绕开 GL 空层 |
| A：canvas 折射 | 已绘制；中心 alpha 1/255（全透） |
| A：色散可见度 | 左圆角青带 b-r 峰值 166、品红带 -68；右圆角青带 185、品红带 -68；肉眼清晰 |
| A：交互 | 点击切换、滑块拖动吸附、胶囊拖拽不误切换，全部通过 |
| A：JS 错误 | 0 |
| 场景 B：现代引擎 UA | `glass-bdurl` 标记，backdrop 为 `url("#glass-refract") saturate(1.06)`，0 错误 |

## Android 10 WebView 兼容验证（v1.5 新增）

> Android 10 出厂 WebView 为 Chromium 74，本沙箱无法运行该引擎；以 Chromium 144 + 对应 UA + 禁用 WebGL 复现「老 WebView + 无 GL 上下文」两个关键差异条件，覆盖降级路径。脚本 `tests/ui/verify-android10.cjs`，可复现。

| 场景 | 结果 |
| --- | --- |
| A：Android 10 WebView UA（Chrome/74）、`--disable-webgl` | 根节点标记 `glass-probed` + `glass-legacy-webview`，**不**含 `glass-bdurl` |
| A：计算后 backdrop | `saturate(1.06)`（独立声明保住），**不含** `url(`（SVG backdrop 被正确降级） |
| A：canvas 软件光学层 | 有绘制；中心像素 alpha 1/255（近全透），左右边缘 b 通道 115/111（青/品红色散可见） |
| A：交互回归 | 点击切换、滑块拖动吸附到最近标签、胶囊拖拽不误切换，全部通过 |
| A：JS 错误 | 0 |
| B：现代引擎 UA（Chrome/120）、WebGL 可用 | `glass-bdurl` 已标记，backdrop 为 `url("#glass-refract") saturate(1.06)`（加分项仍启用），0 JS 错误 |
| 既有 UI 回归 `tests/ui/verify-ui.cjs` | PASS，20 项响应式布局检查，0 错误 |
| Android Lint | **0 错误** |
| `glass.js` 语法 / 无 ES2020（`??`、`?.`） | 通过 / 计数 0 |

## 构建与签名

| 项目 | 结果 |
| --- | --- |
| `:app:assembleRelease` / `assembleDebug` / `assembleDebugAndroidTest` | BUILD SUCCESSFUL |
| 最低版本 / 目标版本 | `minSdk 29`（Android 10）/ `targetSdk 34` |
| 交付 APK 签名 | v3 方案已验证；单一签名者，RSA 3072 位 |
| 签名证书 | `CN=Pilot One Thing Delivery, O=Pilot One Thing` |
| SHA-256（证书） | `ede3c7b64fd0ff2853c6f90032c858aa5a5493d448a6f5dc02d00cd78e5925ca` |
| zipalign | `-c 4` 校验通过 |
| 资源一致性 | APK 内 `assets/ui/` 与工程源码逐字节一致（含亮色与液态玻璃改造） |

## 自动化测试

| 测试 | 结果 | 环境 |
| --- | --- | --- |
| 设备插桩测试 `PilotDeviceTests` | **13/13 通过**（`OK (13 tests)`） | API 29 x86_64 模拟器 |
| 安全规则 `PilotGuardTest` | **108 项通过** | 本地 JVM |
| 服务商适配 `tests/providers/run.sh` | **121 项通过**，无网络、无真实密钥 | 本地 JVM |
| Android Lint | **0 错误 / 11 警告** | `:app:lintDebug` |
| WebView 布局回归 | **20 项通过**，320–900px 五种宽度无横向溢出 | Chromium |
| 无 ES2020 语法 | `??` / `?.` 计数为 0 | `glass.js` 等，Android 10 WebView 74 兼容 |

> 设备插桩脚本包装器退出码为 1，仅因格式化后的 adb 输出省略了末尾原始 `INSTRUMENTATION_CODE` 行；runner 本身明确输出 `OK (13 tests)`，故判定为通过。

## v1.2 视觉改动验证

- **亮色主题**：冷白雾面背景 `rgb(238,243,241)`、白色磨砂卡片、深墨色文字 `rgb(21,38,34)`、青绿强调色。文字对比度经计算：正文 14:1、次要文字 5.3:1、主按钮白字最低 4.7:1，符合 WCAG。
- **清透玻璃反射（v1.4 最终）**：按真实玻璃的菲涅尔特性重做——正对的中心反射率约 4%（几乎全透），只有圆角斜面与光源方向出现清晰镜面高光，边缘保留 RGB 色散。已去除会把中心蒙白的 body 基础着色/环境底光，以及把高光扭成波纹的 SVG 湍流位移滤镜。软件路径分区实测：**中心平均 alpha 1/255、整体平均 8，纯白过曝像素为 0**，身后文字可透过导航清晰阅读；WebGL 路径为 GLSL ES 1.00。（本机 Chromium 无 WebGL，实测软件路径。）
- **通透度根因与量化（v1.4 最终修正）**：canvas alpha 很低≠看起来通透，真正的糊来自 CSS 叠层。在玻璃正后方注入高对比棋盘逐层测量：关闭 `backdrop-filter` 时条纹列对比度从 67.3/峰峰 188.7 恢复到 67.9/245.6、关闭选中滑块时降到 25.3/89.2——确认 `blur(7px)` 糊背景与 94% 白选中药丸是两个主因（裸基准 71.5/255）。移除背景模糊、仅保留 `saturate(106%)`，并把白底/滑块降到近乎透明后，与裸棋盘的相关性（背景保真度）从 **0.173 → 0.931**；玻璃本体改由增强的 canvas 边缘菲涅尔高光（`edge` 增益 0.9→2.2）与内阴影描边呈现，中心仍全透。真实浅色页面上玻璃轮廓清晰、选中态可辨。
- **可见折射（v1.4 最终重做）**：仅靠 `backdrop-filter:url()` 位移背景在浅灰纯色页面上肉眼不可见（纯色位移仍是纯色），且 Android WebView 对 `backdrop-filter:url()` 支持不一。改为在 canvas 光学层直接绘制折射特征，任何背景下可见：圆角**青/品红色散边**、边缘**亮唇 + 内侧暗线**（弯折/全反射）、底缘**焦散亮弧**，中心保持通透。色散以独立加色层 + 自身 alpha 输出（避免被 4% 菲涅尔压制）。软件路径分区实测：侧边因色散 b 通道高于 r/g（29–35 vs 25–29）、侧边平均 alpha 46、顶部 33、底部焦散 31、中心 alpha 1/255、**纯白过曝 0**，Chromium 144 截图确认左右圆角青/品红彩边清晰自然、文字锐利、0 JS 错误；WebGL 路径 GLSL ES 1.00 同步实现（本机无 WebGL，实测软件路径）。`backdrop-filter:url(#glass-refract)` 的 6KB 内联 SDF 位移图作为加分项保留（支持时叠加真实背景弯折，不支持时静默退化）。`prefers-reduced-motion`/减少动态效果时关闭位移层。无网络、无外部资源。
- **可拖动玻璃滑块：力度变形 + Q弹 + bug 修复（v1.4 最终）**：CDP 实测按住滑块拖动——小幅拖放大 `scaleX 1.147/sy 1.025`、大幅拖放大 `1.433`（并沿拖动方向拉长、纵向压到 1.005），形变随力度非线性变化；松手吸附到最近标签（`aria-current deck → links`）、点击切换回归正常。双欠阻尼弹簧（ζ≈0.3）：松手 sx 采样 `1.33 → 1.03 → 0.87 → 1.05 → 1.0`，冲过静止点后多次振荡归位，明显 Q 弹。边界钳制：超量拖动时 `tx` 停在预留放大余量内，滑块圆角始终在导航栏内不被 `overflow:hidden` 裁平。**bug 修复**：命中判定由“未放大宽度”改为滑块实时 `getBoundingClientRect()`（含 transform），实测放大状态下抓滑块最右边缘识别为 `knob=true, capsule=false`（不再误触发胶囊形变），0 JS 错误。滑块为叠在导航玻璃之上的第二层独立玻璃。
- **四向拖拽弹性（v1.3 起，v1.4 保留）**：
  - 横向左右：`scaleX 1.055 / scaleY 0.965`，位移 ±3.4px；
  - 纵向上下：`scaleY 1.088 / scaleX 0.982`，位移 ±2.06px；
  - 斜向：两轴同时形变；幅度为二次非线性（小幅拖拽几乎无形变）；
  - 回弹：五个方向均检测到越过静止点的过冲（欠阻尼弹簧），末值归 1.000；拖拽不误触发标签切换，无 JS 错误。幅度已从上一版 18% 收敛到 5–9%。
  - v1.4 新增：拖拽时内部反射沿拉伸反方向以一阶阻尼滞后流动，随形变归位；CDP 实测斜向拖拽中途 `scale(1.0169,0.9984) skew(-0.47deg)`、松手归 `scale(1,1)`，全程 0 异常。
- **一键复制（v1.4）**：本次反馈面板新增「复制」按钮；注入结果后按钮可见，调用 `document.execCommand('copy')` 并在失败时提示长按手动复制。
- **Chromium 同尺寸（540×960）渲染**：标题、任务区、技能库、连接页全部文字与控件完整，无横向溢出；导航胶囊整块玻璃质感、身后文字可透出、标签清晰，无过曝或毛刺。

## 设备实测（Android 10 / API 29，软件模拟器）

> 以下为 v1.3 及之前版本在带 KVM 加速的模拟器上完成的历史实测；v1.4 的玻璃光学改动在本轮交付环境中因沙箱无硬件加速（KVM 不可用、x86_64 镜像无法启动）未能重跑模拟器，改以 Chromium 144 的等效 CDP 验证覆盖（见上文）。原生宿主逻辑（无障碍、悬浮窗、网络、签名）自 v1.3 起未改动。

- 正式签名 APK 全新安装成功并启动，进程存活，无崩溃日志。
- 无障碍服务 `io.pilot.onething/.PilotAccess` 已成功绑定并处于 Enabled 状态。
- `SYSTEM_ALERT_WINDOW`（悬浮窗）权限为 allow。
- 导航点击实测：指挥台 → 技能库 → 连接，三次切换均在设备上生效（页面内容变化 + 导航滑块位置变化确认）。
- 四向拖拽实测：在导航胶囊上分别向右/左/上/下 swipe，应用无崩溃、进程存活。
- 亮色界面在设备上正常渲染：棱镜、按钮、表单、玻璃胶囊、页面框架均显示。
- 说明：应用启用 `FLAG_SECURE`（防截屏），模拟器的 `screenrecord` 取景对文字合成层捕捉不完整，截图里部分文字"时隐时现"是取证工具局限；同尺寸 Chromium 渲染与 UI 层检查确认文字完整存在，非应用缺陷。

## 未覆盖 / 需用户自测

- 真实模型/搜索 API 调用（无用户密钥，未做联网实测；适配层已用固定响应解析验证）。
- 物理真机与厂商定制系统的无障碍兼容性、开屏提示、后台保活差异。
- debug 与正式签名证书不同，二者不可直接覆盖升级；全新安装正式包不受影响。
- 已签名 release APK 在真机上的安装来源提示。

详细端到端步骤与证据见 [E2E.md](E2E.md)。
